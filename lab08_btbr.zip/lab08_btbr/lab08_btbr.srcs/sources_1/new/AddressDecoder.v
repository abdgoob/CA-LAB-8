`timescale 1ns / 1ps

module AddressDecoder(
    input [31:0] address,

    input readEnable,
    input writeEnable,

    output reg DataMemRead,
    output reg DataMemWrite,

    output reg LEDWrite,
    output reg SwitchReadEnable
);

always @(*) begin

    DataMemRead     = 1'b0;
    DataMemWrite    = 1'b0;
    LEDWrite        = 1'b0;
    SwitchReadEnable = 1'b0;


    if (address[9] == 1'b0) begin

        DataMemRead  = readEnable;
        DataMemWrite = writeEnable;

    end

    else if (address[9:8] == 2'b10) begin

        LEDWrite = writeEnable;

    end

    else if (address[9:8] == 2'b11) begin

        SwitchReadEnable = readEnable;

    end

end

endmodule