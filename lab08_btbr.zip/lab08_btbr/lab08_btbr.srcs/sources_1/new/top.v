`timescale 1ns / 1ps
module Lab8_FPGA_Top(
input clk,
input pbin,
input [15:0] physical_sw,
output reg [15:0] physical_leds,
output reg [6:0] seg,
output [3:0] an,
output dp
);
// --------------------------------------------------
// Mode
//
// 00 = Memory Read
// 01 = Memory Write
// 10 = LED Write
// 11 = Switch Read
// --------------------------------------------------
wire [1:0] mode;
assign mode = physical_sw[15:14];
wire [7:0] value;
assign value = physical_sw[7:0];

// --------------------------------------------------
// Debounced center button
// Used as WRITE / EXECUTE button
// --------------------------------------------------
wire write_button;
debouncer db1(
.clk(clk),
.pbin(pbin),
.pbout(write_button)
);

// --------------------------------------------------
// Memory-system signals
// --------------------------------------------------
reg [31:0] address;
reg readEnable;
reg writeEnable;
wire [31:0] readData;
wire [15:0] device_leds;
wire [31:0] writeData;
assign writeData = {24'd0, value};

// --------------------------------------------------
// Address + control
// --------------------------------------------------
always @(*) begin
address = 32'd0;
readEnable = 1'b0;
writeEnable = 1'b0;
case(mode)
// MEMORY READ
// SW7:0 = address
2'b00: begin
address = {24'd0, value};
readEnable = 1'b1;
end

// MEMORY WRITE
// SW7:0 = address AND test value
//
// Press center button to write.
2'b01: begin
address = {24'd0, value};
writeEnable = write_button;
end

// LED WRITE
//
// SW7:0 = LED data
// Press center button to store it.
2'b10: begin
address = 32'd512;
writeEnable = write_button;
end

// SWITCH READ
//
// SW7:0 is returned through switch interface.
2'b11: begin
address = 32'd768;
readEnable = 1'b1;
end
endcase
end

// --------------------------------------------------
// Memory System from Task 2
// --------------------------------------------------
addressDecoderTop memory_system(
.clk(clk),
// Button is now WRITE button, not reset.
.rst(1'b0),
.address(address),
.readEnable(readEnable),
.writeEnable(writeEnable),
.writeData(writeData),
// Only lower 8 switches are peripheral input.
.switches({8'd0, value}),
.readData(readData),
.leds(device_leds)
);

// --------------------------------------------------
// Physical LEDs
// --------------------------------------------------
always @(*) begin
case(mode)
// Memory Read
2'b00:
physical_leds = readData[15:0];
// Memory Write
// Show what you are about to write
2'b01:
physical_leds = {8'd0, value};
// LED Write
// Show stored LED peripheral value
2'b10:
physical_leds = device_leds;
// Switch Read
2'b11:
physical_leds = readData[15:0];
default:
physical_leds = 16'd0;
endcase
end

// --------------------------------------------------
// Seven Segment
//
// Right-most digit only:
//
// 0 = Memory Read
// 1 = Memory Write
// 2 = LED Write
// 3 = Switch Read
//
// Active-low Basys 3 segments
// --------------------------------------------------
assign an = 4'b1110;
assign dp = 1'b1;
always @(*) begin
case(mode)
2'b00:
seg = 7'b1000000; // 0
2'b01:
seg = 7'b1111001; // 1
2'b10:
seg = 7'b0100100; // 2
2'b11:
seg = 7'b0110000; // 3
default:
seg = 7'b1111111;
endcase
end
endmodule