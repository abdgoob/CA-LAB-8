module debouncer(
    input clk,
    input pbin,
    output reg pbout
);

reg [19:0] count;
reg btn_sync1;
reg btn_sync2;

// Synchronize push button to FPGA clock
always @(posedge clk) begin
    btn_sync1 <= pbin;
    btn_sync2 <= btn_sync1;
end

// Debounce
always @(posedge clk) begin

    if (btn_sync2 == pbout) begin
        count <= 20'd0;
    end

    else begin

        if (count == 20'd999999) begin
            pbout <= btn_sync2;
            count <= 20'd0;
        end

        else begin
            count <= count + 1'b1;
        end

    end

end

initial begin
    count = 20'd0;
    pbout = 1'b0;
    btn_sync1 = 1'b0;
    btn_sync2 = 1'b0;
end

endmodule