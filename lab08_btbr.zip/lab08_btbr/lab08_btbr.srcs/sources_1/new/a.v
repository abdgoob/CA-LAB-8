`timescale 1ns / 1ps

module addressDecoderTop(

    input clk,
    input rst,

    input [31:0] address,

    input readEnable,
    input writeEnable,

    input [31:0] writeData,

    input [15:0] switches,

    output [31:0] readData,
    output [15:0] leds

);


wire DataMemRead;
wire DataMemWrite;

wire LEDWrite;
wire SwitchReadEnable;

wire [31:0] memoryReadData;
wire [31:0] switchReadData;


AddressDecoder decoder (

    .address(address),

    .readEnable(readEnable),
    .writeEnable(writeEnable),

    .DataMemRead(DataMemRead),
    .DataMemWrite(DataMemWrite),

    .LEDWrite(LEDWrite),
    .SwitchReadEnable(SwitchReadEnable)

);

DataMemory data_memory (

    .clk(clk),

    .MemWrite(DataMemWrite),
    .MemRead(DataMemRead),

    .address(address[8:0]),

    .write_data(writeData),

    .read_data(memoryReadData)

);

switches led_interface (

    .clk(clk),
    .rst(rst),

    .writeData(writeData),

    .writeEnable(LEDWrite),
    .readEnable(1'b0),

    .memAddress(address[29:0]),

    .readData(),

    .leds(leds)

);

leds switch_interface (

    .clk(clk),
    .rst(rst),

    .btns(16'd0),

    .writeData(32'd0),
    .writeEnable(1'b0),

    .readEnable(SwitchReadEnable),

    .memAddress(address[29:0]),

    .switches(switches),

    .readData(switchReadData)

);

assign readData =
       DataMemRead
       ? memoryReadData

       : SwitchReadEnable
       ? switchReadData

       : 32'b0;


endmodule
`timescale 1ns / 1ps

module addressDecoderTop(

    input clk,
    input rst,

    input [31:0] address,

    input readEnable,
    input writeEnable,

    input [31:0] writeData,

    input [15:0] switches,

    output [31:0] readData,
    output [15:0] leds

);


wire DataMemRead;
wire DataMemWrite;

wire LEDWrite;
wire SwitchReadEnable;

wire [31:0] memoryReadData;
wire [31:0] switchReadData;


AddressDecoder decoder (

    .address(address),

    .readEnable(readEnable),
    .writeEnable(writeEnable),

    .DataMemRead(DataMemRead),
    .DataMemWrite(DataMemWrite),

    .LEDWrite(LEDWrite),
    .SwitchReadEnable(SwitchReadEnable)

);

DataMemory data_memory (

    .clk(clk),

    .MemWrite(DataMemWrite),
    .MemRead(DataMemRead),

    .address(address[8:0]),

    .write_data(writeData),

    .read_data(memoryReadData)

);

switches led_interface (

    .clk(clk),
    .rst(rst),

    .writeData(writeData),

    .writeEnable(LEDWrite),
    .readEnable(1'b0),

    .memAddress(address[29:0]),

    .readData(),

    .leds(leds)

);

leds switch_interface (

    .clk(clk),
    .rst(rst),

    .btns(16'd0),

    .writeData(32'd0),
    .writeEnable(1'b0),

    .readEnable(SwitchReadEnable),

    .memAddress(address[29:0]),

    .switches(switches),

    .readData(switchReadData)

);

assign readData =
       DataMemRead
       ? memoryReadData

       : SwitchReadEnable
       ? switchReadData

       : 32'b0;


endmodule
