`timescale 1ns / 1ps
module Lab8_FPGA_Top(
input clk,
input pbin,
input [15:0] physical_sw,
output [15:0] physical_leds,
output [6:0] seg,
output [3:0] an,
output dp
);

// RESET
wire rst_clean;
debouncer rst_db (
.clk(clk),
.pbin(pbin),
.pbout(rst_clean)
);

// SYNCHRONIZE PHYSICAL SWITCHES
reg [15:0] sw_stage1;
reg [15:0] sw_sync;
always @(posedge clk) begin
sw_stage1 <= physical_sw;
sw_sync <= sw_stage1;
end
// MODE
// SW15:14
// 00 = Memory Read
// 01 = Memory Write
// 10 = LED Write
// 11 = Switch Read
wire [1:0] mode;
assign mode = sw_sync[15:14];

// SW7:0 = test address / value
wire [7:0] input_value;
assign input_value = sw_sync[7:0];

reg [1:0] previous_mode;
always @(posedge clk or posedge rst_clean) begin
if (rst_clean)
previous_mode <= 2'b00;
else
previous_mode <= mode;
end

wire memory_write_pulse;
assign memory_write_pulse =
(mode == 2'b01) &&
(previous_mode != 2'b01);

wire led_write_pulse;
assign led_write_pulse =
(mode == 2'b10) &&
(previous_mode != 2'b10);

// MEMORY SYSTEM SIGNALS
reg [31:0] address;
reg readEnable;
reg writeEnable;
wire [31:0] readData;
wire [15:0] device_leds;

wire [31:0] writeData;
assign writeData = {
24'd0,
input_value
};

// ADDRESS + CONTROL
always @(*) begin
address = 32'd0;
readEnable = 1'b0;
writeEnable = 1'b0;

case(mode)

// 00 - MEMORY READ
2'b00: begin
address = {
24'd0,
input_value
};
readEnable = 1'b1;
end

// 01 - MEMORY WRITE
2'b01: begin
address = {
24'd0,
input_value
};
writeEnable = memory_write_pulse;
end

// 10 - LED WRITE
2'b10: begin
address = 32'd512 +
{
24'd0,
input_value
};
writeEnable = led_write_pulse;
end

// 11 - SWITCH READ
2'b11: begin
address = 32'd768;
readEnable = 1'b1;
end

endcase
end

// TASK 2 MEMORY SYSTEM

addressDecoderTop memory_system (
.clk(clk),
.rst(rst_clean),
.address(address),
.readEnable(readEnable),
.writeEnable(writeEnable),
.writeData(writeData),
.switches({
8'd0,
input_value
}),
.readData(readData),
.leds(device_leds)
);


reg [15:0] display_data;
always @(*) begin
case(mode)

// Memory Read:
// show actual stored data
2'b00:
display_data = readData[15:0];

// Memory Write:
// show what we are writing
2'b01:
display_data = {
8'd0,
input_value
};

// LED Write:
// show value stored in LED interface
2'b10:
display_data = device_leds;

// Switch Read:
// show switch value read through memory system
2'b11:
display_data = readData[15:0];

default:
display_data = 16'd0;
endcase
end

assign physical_leds = display_data;

sevenseg_state state_display (
.clk(clk),
.mode(mode),
.seg(seg),
.an(an),
.dp(dp)
);

endmodule