`timescale 1ns / 1ps

module leds(
    input clk,
    input rst,
    
    input [15:0] btns,
    input [31:0] writeData,
    input writeEnable,
    input readEnable,
    input [29:0] memAddress,
    input [15:0] switches,
    
    output reg [31:0] readData = 32'd0
    );
    
always @(posedge clk or posedge rst) begin
    if (rst) begin
        readData <= 31'd0;
    end
    
    else begin
        if (readEnable)
            readData <= {16'd0, switches};
        else
            readData <= 32'd0;
    end
    
 end      
 
endmodule
