`timescale 1ns / 1ps
module sevenseg_state(
input clk,
input [1:0] mode,
output reg [6:0] seg,
output reg [3:0] an,
output dp
);

// Refresh counter
reg [17:0] refresh_counter = 18'd0;
always @(posedge clk)
refresh_counter <= refresh_counter + 1'b1;

wire [1:0] digit_select;
assign digit_select = refresh_counter[17:16];

// Decimal point OFF
assign dp = 1'b1;

// Character codes
localparam BLANK = 5'd0;
localparam CHAR_r = 5'd1;
localparam CHAR_E = 5'd2;
localparam CHAR_A = 5'd3;
localparam CHAR_d = 5'd4;
localparam CHAR_S = 5'd5;
localparam CHAR_t = 5'd6;
localparam CHAR_o = 5'd7;
localparam CHAR_L = 5'd8;
localparam CHAR_W = 5'd9;

reg [4:0] character;
always @(*) begin
character = BLANK;

case(mode)

// MEMORY READ
// rEAd
2'b00: begin
case(digit_select)
2'b00: character = CHAR_d;
2'b01: character = CHAR_A;
2'b10: character = CHAR_E;
2'b11: character = CHAR_r;
endcase
end

// MEMORY WRITE
// Stor = Store
2'b01: begin
case(digit_select)
2'b00: character = CHAR_r;
2'b01: character = CHAR_o;
2'b10: character = CHAR_t;
2'b11: character = CHAR_S;
endcase
end

// LED WRITE
// LEd
2'b10: begin
case(digit_select)
2'b00: character = BLANK;
2'b01: character = CHAR_d;
2'b10: character = CHAR_E;
2'b11: character = CHAR_L;
endcase
end

// SWITCH READ
// SW
2'b11: begin
case(digit_select)
2'b00: character = BLANK;
2'b01: character = BLANK;
2'b10: character = CHAR_W;
2'b11: character = CHAR_S;
endcase
end

endcase
end

always @(*) begin
case(digit_select)
2'b00:
an = 4'b1110;
2'b01:
an = 4'b1101;
2'b10:
an = 4'b1011;
2'b11:
an = 4'b0111;
default:
an = 4'b1111;
endcase
end


always @(*) begin
case(character)
BLANK:
seg = 7'b1111111;

// r
CHAR_r:
seg = 7'b1111010;

// E
CHAR_E:
seg = 7'b0110000;

// A
CHAR_A:
seg = 7'b0001000;

// d
CHAR_d:
seg = 7'b1000010;

// S
CHAR_S:
seg = 7'b0100100;

// t
CHAR_t:
seg = 7'b1110000;

// o
CHAR_o:
seg = 7'b1100010;

// L
CHAR_L:
seg = 7'b1110001;

// W approximation
CHAR_W:
seg = 7'b1000001;

default:
seg = 7'b1111111;
endcase
end

endmodule