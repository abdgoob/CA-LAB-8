`timescale 1ns / 1ps

module MemorySystem_tb;


reg clk;
reg rst;

reg [31:0] address;

reg readEnable;
reg writeEnable;

reg [31:0] writeData;

reg [15:0] switches;


wire [31:0] readData;
wire [15:0] leds;


addressDecoderTop uut (

    .clk(clk),
    .rst(rst),

    .address(address),

    .readEnable(readEnable),
    .writeEnable(writeEnable),

    .writeData(writeData),

    .switches(switches),

    .readData(readData),
    .leds(leds)

);


initial begin

    clk = 0;

    forever #5 clk = ~clk;

end


initial begin

    // Initial values
    rst = 1;

    address = 0;

    readEnable = 0;
    writeEnable = 0;

    writeData = 0;

    switches = 16'h0000;


    #20;

    rst = 0;




    address = 32'd10;

    writeData = 32'hDEADBEEF;

    writeEnable = 1;
    readEnable = 0;

    #10;

    writeEnable = 0;


    readEnable = 1;

    #10;

    $display(
        "MEMORY READ: Address=%d Data=%h",
        address,
        readData
    );


    readEnable = 0;


    address = 32'h00000210;

    writeData = 32'h000000A5;

    writeEnable = 1;

    #10;

    writeEnable = 0;

    #10;

    $display(
        "LED WRITE: LEDs=%h",
        leds
    );

    switches = 16'h5A3C;

    address = 32'h00000350;

    readEnable = 1;

    #10;

    $display(
        "SWITCH READ: Switches=%h ReadData=%h",
        switches,
        readData
    );


    readEnable = 0;


    #20;

    $finish;

end

endmodule